<?php 
include 'koneksi.php';

$nama =$_POST['nama'];
$pesan =$_POST['pesan'];

$simpan =mysqli_query($konek, "INSERT INTO `tb_pesan` (`id_pesan`,`nama`,`pesan`) VALUES (null, '$nama', '$pesan')");
header("Location:index.php");

 ?>