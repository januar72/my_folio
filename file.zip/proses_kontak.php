<?php 
include 'koneksi.php';
$nama =$_POST['nama'];
$email =$_POST['email'];
$no_hp =$_POST['no_hp'];
$pesan =$_POST['pesan'];

$simpan=mysqli_query($konek, "INSERT INTO `tb_kontak` (`id_kontak`,`nama`,`email`,`no_hp`,`pesan`) VALUES (null, '$nama','$email','$no_hp','$pesan')");
header("location:kontak.php");
exit();

 ?>