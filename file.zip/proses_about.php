<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$visi =$_POST['visi'];
	$misi =$_POST['misi'];

$simpan =mysqli_query($konek, "INSERT INTO `tb_about` (`id_about`,`visi`,`misi`) VALUES (null, '$visi','$misi')");
header("Location:dashboard_admin.php?p=data_about&notif=sukses");
}

 ?>

