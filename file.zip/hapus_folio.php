<?php 
include 'koneksi.php';

$id =$_GET['id'];

$hapus=mysqli_query($konek, "DELETE FROM tb_myfolio WHERE id_folio='$id'");
header("Location:dashboard_admin.php?p=data_folio");

 ?>