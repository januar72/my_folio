<?php
 session_start();
include "koneksi.php";
    if (isset($_POST['masuk'])) {
        $user = $_POST['username'];
        $pass = $_POST['password'];
        $cek = mysqli_query($konek, "SELECT * FROM tb_user WHERE username='$user' AND password='$pass' AND status='Aktif'");
        $result = mysqli_num_rows($cek);
        $data = mysqli_fetch_array($cek);
        if ($result > 0) {
            if ($data['jabatan']=='admin') {
                $_SESSION['masuk'] = $user;
                 header("location:dashboard_admin.php");
            }elseif ($data['jabatan']=='owner') {
                $_SESSION['owner'] = $user;
                header("location:dashboard_owner.php");
            }
        }else if ($result ==0) {
                header("location:index.php?notif=gagal");
            }
        }
        
?>