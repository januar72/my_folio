<?php 
include 'koneksi.php';

	$direktori ="berkas/";
	$file_name =$_FILES['gambar']['name'];
	move_uploaded_file($_FILES['gambar']['tmp_name'],$direktori.$file_name);

$simpan =mysqli_query($konek, "INSERT INTO `tb_baner` (`id_baner`,`gambar`) VALUES (null, '$file_name')");
header("Location:dashboard_admin.php?p=data_baner&notif=sukses");

 ?>
