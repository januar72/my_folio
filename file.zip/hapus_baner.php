<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus =mysqli_query($konek, "DELETE FROM tb_baner WHERE id_baner='$id'");
header("Location:dashboard_admin.php?p=data_baner&notif=sukses_hapus");

 ?>