<?php 
include 'koneksi.php';

$nama =$_POST['nama'];
$jabatan =$_POST['jabatan'];
$username =$_POST['username'];
$password =$_POST['password'];

// tampilkan data
$tampil =mysqli_query($konek, "SELECT * FROM tb_user WHERE username='$username' ");
$result =mysqli_num_rows($tampil);
$data =mysqli_fetch_array($tampil);
if ($result > 0) {
	header("Location:dashboard_admin.php?p=index_admin&notif=gagal");
}elseif ($result == 0) {
	$simpan =mysqli_query($konek, "INSERT INTO `tb_user` (`id_user`,`nama`,`jabatan`,`username`,`password`,`status`) VALUES (null, '$nama', '$jabatan','$username', '$password', 'Aktif') ");
	header("Location:dashboard_admin.php?p=index_admin&notif=sukses");
}
 ?>