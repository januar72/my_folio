<?php 
include 'koneksi.php';

	$direktori ="berkas/";
	$file_name =$_FILES['foto']['name'];
	move_uploaded_file($_FILES['foto']['tmp_name'], $direktori.$file_name);
	$judul =$_POST['judul'];
	$created_by =$_POST['created_by'];
	$berita =$_POST['berita'];

$simpan =mysqli_query($konek, "INSERT INTO `tb_project` (`id_project`,`judul`,`created_by`,`berita`,`foto`) VALUES (null, '$judul','$created_by','$berita','$file_name')");
header("Location:dashboard_admin.php?p=data_progres&notif=sukses");

 ?>

