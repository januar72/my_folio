<?php 
include 'koneksi.php';

$id =$_GET['id'];

$tampil=mysqli_query($konek, "SELECT * FROM tb_pesan WHERE id_pesan='$id'");
$data =mysqli_fetch_array($tampil);
if ($data['status'] == 1) {
$ubah =mysqli_query($konek, "UPDATE tb_pesan SET status='0' WHERE id_pesan='$id'");
}else{
    $ubah =mysqli_query($konek, "UPDATE tb_pesan SET status='1' WHERE id_pesan='$id'");
}
header("Location:dashboard_admin.php?p=detail_pesan");

 ?>