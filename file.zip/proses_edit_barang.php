<?php
include "koneksi.php";
$id=$_GET['id'];
$nama = $_POST['nama'];
$satuan = $_POST['satuan'];
$kategori= $_POST['kategori'];
$stok= $_POST['stok'];
$query_simpan=mysqli_query($konek, "UPDATE tbl_barang SET nm_barang='$nama', satuan='$satuan', kategori='$kategori', stok='$stok' WHERE id_barang='$id'");
header("location:dashboard_admin.php?p=barang&notif=sukses_edit");
?>