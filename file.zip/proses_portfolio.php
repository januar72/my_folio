<?php 
include 'koneksi.php';

$direktori ="berkas/";
$file_name =$_FILES['baner']['name'];
move_uploaded_file($_FILES['baner']['tmp_name'], $direktori.$file_name);
$ket =htmlspecialchars($_POST['ket']);
$proj =htmlspecialchars($_POST['proj']);
 $file_cv =htmlspecialchars($_FILES['cv']['name']);
  $tmp =htmlspecialchars($_FILES['cv']['tmp_name']);
  $path ="./berkas/".$file_cv;
  move_uploaded_file($tmp, $path);

$simpan=mysqli_query($konek, "INSERT INTO `tb_myfolio` (`id_folio`,`ket`,`proj`,`cv`,`baner`) VALUES (null, '$ket','$proj','$file_cv','$file_name')");
// var_dump($simpan);
// die();
header("Location:dashboard_admin.php?p=data_folio&notif=sukses");

 ?>
