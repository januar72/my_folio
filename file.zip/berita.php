<?php include 'templates/header.php'; ?>
<?php include 'templates/navbar.php'; ?>
<section class="berita" id="berita">
	<div class="container">
		<div class="row mb-3 mt-5">
			<div class="col mt-5 text-center">
				<h3>My <span>Progres</span></h3>
			</div>
		</div>
		<div class="row justify-content-center">
			<?php include 'koneksi.php';
			$id =$_GET['id'];
			$panggil=mysqli_query($konek,"SELECT * FROM tb_project WHERE id_project='$id'");
			while ($data=mysqli_fetch_array($panggil, MYSQLI_ASSOC)) { ?>
			<div class="col">
				<div class="card bg-dark text-white">
				  <div class="card-img-overlay  justify-content-center">
				  </div>
				</div>
			</div>
			<h5 class="card-title"><?php echo $data['judul']; ?></h5>
			<p><?php echo $data['berita']; ?></p>
		<?php } ?>
		</div>
	</div>
</section>
<!-- akhir index berita -->
<!-- awal index berita -->

<?php include 'templates/footer.php'; ?>