  <?php include 'templates/header.php'; ?>
  <?php include 'templates/navbar.php'; ?>
  <!-- projects -->
   <section class="project" id="project">
     <div class="container">
       <div class="row mb-3 mt-5">
         <div class="col mt-5">
           <h2>My <span>Folio</span></h2>
         </div>
       </div>
       <div class="row justify-content-evenly">
        <?php include 'koneksi.php';
          $tampil=mysqli_query($konek, "SELECT * FROM tb_myfolio");
          while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) { ?>
         <div class="col-md-4 mb-3">
           <div class="card">
            <img src="./berkas/<?php echo $data['baner']; ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <p class="card-text"><?php echo $data['ket']; ?></p>
              <a href="<?php echo $data['proj']; ?>" class="btn btn-primary">Go somewhere</a>
              <a href="download.php?filename=<?php echo $data['cv']; ?>" class="btn btn-danger">Download CV</a>
            </div>
          </div>
         </div>
           <?php } ?>
       </div>
     </div>
   </section>
   <!-- akhir projects -->
   <?php include 'templates/footer.php'; ?>