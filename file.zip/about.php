<?php include 'templates/header.php'; ?>
<?php include 'templates/navbar.php'; ?>
<!-- about -->
   <section class="about" id="about">
     <div class="container">
       <div class="row text-center mb-4 mt-5">
         <div class="col mt-5">
           <h2>About <span>Me</span></h2>
         </div>
       </div>
       <div class="row justify-content-center fs-5 text-center">
         <div class="judul col-md-4 mb-3">
           Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
           tempor incididunt ut labore et dolore magna aliqua. 
         </div>
         <div class="judul col-md-4 mb-3">
           Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
           tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
           quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
           consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
           cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
           proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
         </div>
       </div>
     </div>
   </section>
   <!-- akhir about -->
   <?php include 'templates/footer.php'; ?>