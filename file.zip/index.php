<?php include 'templates/header.php'; ?>
<?php include 'templates/navbar.php'; ?>
<!-- awal carousel -->
<section class="wraper mt-5">
  <div class="slides">
    <span id="slide-1"></span>
    <span id="slide-2"></span>
    <span id="slide-3"></span>
    <div class="image">
        <?php include 'koneksi.php';
        $tampil=mysqli_query($konek, "SELECT * FROM tb_baner");
        while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) { ?>
          <img src="./berkas/<?php echo $data['gambar']; ?>">
        <?php } ?>
    </div>
  </div>
  <div class="navigasi">
    <a href="#slide-1">1</a>
    <a href="#slide-2">2</a>
    <a href="#slide-3">3</a>
  </div>
</section>
<!-- akhir carousel -->

   <!-- projects -->
   <section class="project" id="project">
     <div class="container">
       <div class="row mb-3">
         <div class="col mt-5">
           <h2>My <span>Project</span></h2>
         </div>
       </div>
       <div class="row justify-content-evenly">
        <?php include 'koneksi.php';
        $databanyak =6;
        $banyakdata =mysqli_num_rows(mysqli_query($konek, "SELECT * FROM tb_project"));
        $halamanpenuh =ceil($banyakdata / $databanyak);
        if (isset($_GET['halaman'])) {
          $halamanAktif =$_GET['halaman'];
        }else{
          $halamanAktif =1;
        }
        $awal =($halamanAktif * $databanyak) - $databanyak;

        $panggil=mysqli_query($konek,"SELECT * FROM tb_project LIMIT $awal, $databanyak");
        while ($data=mysqli_fetch_array($panggil, MYSQLI_ASSOC)) { ?>
         <div class="col-md-4 mb-3">
           <div class="card rounded-3">
            <img src="berkas/<?php echo $data['foto'] ?>" class="card-img-top rounded-3" alt="maaf gam kosong.!">
            <div class="card-body">
              <p class="card-text"><?php echo substr(strip_tags($data['berita']), 0, 200); ?></p>
              <a href="karya.php?id=<?php echo $data['id_project']; ?>" class="btn btn-primary border-danger">Baca Selengkapnya</a>
            </div>
          </div>
         </div>
       <?php } ?>
       </div>
     </div>

     <nav aria-label="Page navigation example">
	  <ul class="pagination justify-content-center">
	    <li class="page-item">
	      <a class="page-link" href="#" aria-label="Previous">
	        <span aria-hidden="true">&laquo;</span>
	      </a>
	    </li>
      <?php for ($i=1; $i <= $halamanpenuh; $i++) { ?>
	    <li class="page-item">
        <a class="page-link" href="?halaman=<?php echo $i; ?>"><?php echo $i; ?></a>
      </li>
      <?php } ?>
	    <li class="page-item">
	      <a class="page-link" href="#" aria-label="Next">
	        <span aria-hidden="true">&raquo;</span>
	      </a>
	    </li>
	  </ul>
	</nav>
     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#fff" fill-opacity="1" d="M0,160L40,170.7C80,181,160,203,240,197.3C320,192,400,160,480,133.3C560,107,640,85,720,96C800,107,880,149,960,181.3C1040,213,1120,235,1200,213.3C1280,192,1360,128,1400,96L1440,64L1440,320L1400,320C1360,320,1280,320,1200,320C1120,320,1040,320,960,320C880,320,800,320,720,320C640,320,560,320,480,320C400,320,320,320,240,320C160,320,80,320,40,320L0,320Z"></path></svg>
   </section>
   <!-- akhir projects -->

<!-- awal testimoni -->
<section class="tes">
  <div class="container">
    <div class="testimonial">
      <div class="testimonial-text">
        <?php include 'koneksi.php';
        $tampil=mysqli_query($konek, "SELECT * FROM tb_pesan WHERE status='1' ORDER BY id_pesan ASC");
        while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) { ?>
        <div class="user-text active-text">
          <i class="fas  fa-quote-left"></i>
          <p><?php echo $data['pesan']; ?></p>
           <i class="fas  fa-quote-left"></i>
          <span><?php echo $data['nama']; ?></span>
        </div>
      <?php } ?>
      </div>
      <div class="testimonial-pic">
        <img src="berkas/avatar.png" class="user-pic" onclick="showReview()">
        <img src="berkas/avatar.png" class="user-pic " onclick="showReview()">
        <img src="berkas/avatar.png" class="user-pic active-pic" onclick="showReview()">
      </div>
    </div>
  </div>
  <script type="text/javascript">
  let userTexts =document.getElementsByClassName("user-text");
let userPics =document.getElementsByClassName("user-pic");

  function showReview() {
    for(userPic of userPics){
      userPic.classList.remove("active-pic");
    }
    for(userText of userTexts){
      userText.classList.remove("active-text");
    }
    let i =Array.from(userPics).indexOf(event.target);

    userPics[i].classList.add("active-pic");
    userTexts[i].classList.add("active-text");
  }
</script>
</section>
  <!-- akhir testimoni -->

    <!-- kontak -->
   <section class="contact" id="contact">
     <div class="container">
       <div class="row text-center mb-3">
         <div class="col">
           <h2><span>Testimoni</span></h2>
         </div>
       </div>
       <div class="row justify-content-center">
         <div class="col-md-8">
           <form method="post" action="kirim_pesan.php">
            <div class="mb-3">
              <label for="nama" class="form-label">Name</label>
              <input type="text" name="nama" class="form-control" placeholder="masukan nama" id="nama" required>
            </div>

            <div class="mb-3">
              <label for="pesan" class="form-label">Testimoni</label>
              <textarea class="form-control" required placeholder="kirimkan pesan anda" id="pesan" name="pesan" rows="5"></textarea>
            </div>

            <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
          </form>
         </div>
       </div>
     </div>
   </section>
   <!-- akhir kontak -->
<?php include 'templates/footer.php'; ?>

