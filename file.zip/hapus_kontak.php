<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus=mysqli_query($konek, "DELETE FROM tb_kontak WHERE id_kontak='$id'");
header("Location:dashboard_admin.php?p=detail_pesan&notif=sukses_hapus");
 ?>