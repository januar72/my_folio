  <?php include 'templates/header.php'; ?>
  <?php include 'templates/navbar.php'; ?>
  <!-- kontak -->
   <section class="contact" id="contact">
     <div class="container">
       <div class="row text-center mb-3 mt-5">
         <div class="col mt-5 mb-3">
           <h2>Kontak <span>Kami</span></h2>
         </div>
       </div>
       <div class="row justify-content-center">
         <div class="col-md-8">
           <form method="post" action="proses_kontak.php">
            <div class="mb-3">
              <label for="nama" class="form-label">Nama</label>
              <input type="text" name="nama" class="form-control" required placeholder="your name.." id="nama" >
            </div>

            <div class="mb-3">
              <label for="email" class="form-label">Email </label>
              <input type="email" name="email" placeholder="email" required class="form-control" id="email">
            </div>

            <div class="mb-3">
              <label for="no_hp" class="form-label">No Wa</label>
              <input type="text" name="no_hp"  required class="form-control">
            </div>

            <div class="mb-3">
              <label for="exampleFormControlTextarea1" class="form-label">Pesan</label>
              <textarea class="form-control" name="pesan" required id="exampleFormControlTextarea1" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
         </div>
       </div>
     </div>
   </section>
   <?php include 'templates/footer.php'; ?>