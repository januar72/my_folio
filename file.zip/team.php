<?php include 'templates/header.php'; ?>
<?php include 'templates/navbar.php'; ?>
<section class="team" id="team">
	<div class="container">
		<div class="row mb-3 mt-5 ">
			<div class="col mt-5 text-center">
				<h3>My <span>Team</span></h3>
			</div>
		</div>
		<div class="row justify-content-evenly">
			<?php include 'koneksi.php';
			$panggil =mysqli_query($konek, "SELECT * FROM tb_angota");
			while ($data=mysqli_fetch_array($panggil, MYSQLI_ASSOC)) { ?>
			<div class="col-md-4 mb-3">
				<div class="card mb-3">
				  <div class="row g-0">
				    <div class="col-md-4 mb-3">
				      <img src="berkas/<?php echo $data['foto']; ?>" class="img-fluid rounded-3" alt="..." width="300">
				    </div>
				    <div class="col-md-8">
				      <div class="card-body">
				        <h5 class="card-title text-danger"><?php echo $data['profesi']; ?></h5>
				        <p class="card-text"><?php echo $data['biografi']; ?></p>
				      </div>
				    </div>
				  </div>
				</div>
			</div>
			<?php } ?>
		</div>
	</div>
</section>
<?php include 'templates/footer.php'; ?>
