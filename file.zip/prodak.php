<?php include 'templates/header.php'; ?>
<?php include 'templates/navbar.php'; ?>
<section class="prodak" id="prodak">
	<div class="container">
	<div class="row mb-3 mt-5">
		<div class="col md-3 mt-5 text-center">
			<h3>My <span>Prodak</span></h3>
		</div>
	</div>
	<div class="row">
		<?php include 'koneksi.php';
		$panggil=mysqli_query($konek, "SELECT * FROM tb_prodak");
		while ($data=mysqli_fetch_array($panggil, MYSQLI_ASSOC)) { ?>
		<div class="col-md-3 mb-3">
			<div class="card">
			  <img src="berkas/<?php echo $data['gambar']; ?>" class="card-img-top" alt="...">
			  <div class="card-body">
			    <h5 class="card-title"><?php echo $data['judul']; ?></h5>
			    <p class="card-text"><?php echo $data['deskripsi']; ?></p>
			    <p class="text-center">Rp. 30.000</p>
			    <p class="m-1" style="color: orange;">
		    	 <i class="fas fa-star"></i>
		    	 <i class="fas fa-star"></i>
		    	 <i class="fas fa-star"></i>
			    </p>
			  </div>
			</div>
		</div>
	<?php } ?>
	</div>
</div>
</section>
<?php include 'templates/footer.php'; ?>