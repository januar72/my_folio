<?php include 'templates/header.php'; ?>
<?php include 'templates/navbar.php'; ?>
<section class="karya" id="karya">
	<div class="container">
		<?php include 'koneksi.php';
		$id =$_GET['id'];
		$tampil=mysqli_query($konek, "SELECT * FROM tb_project WHERE id_project='$id'");
		while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) { ?>
		<div class="row mt-5 mb-3 justify-content-center fs-5 text-center">
			<div class="col mt-5 mb-3">
				<h3 style="font-style: italic; color: black;"><?php echo $data['judul']; ?></h3>
				<p style="color: orange; font-size: 12px;">(<?php echo $data['created_at']; ?>)</p>
			</div>
			<div class="tulisan">
				<p>
					<?php echo $data['berita']; ?>
				</p>
			</div>
			<div class="created mt-5">
				<p style="color: orange; font-style: italic; font-family: Arial; font-size: 12px;">Created by &copy; <?php echo $data['created_by']; ?></p>
			</div>
		</div>
	<?php } ?>
	</div>
</section>
<?php include 'templates/footer.php'; ?>