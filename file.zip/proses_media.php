<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$alamat =$_POST['alamat'];
	$email =$_POST['email'];
	$no_hp =$_POST['no_hp'];
	$maps =$_POST['maps'];
	$yt =$_POST['yt'];
	$ig =$_POST['ig'];
	$tiktok =$_POST['tiktok'];
$simpan =mysqli_query($konek, "INSERT INTO tb_media (`id_media`,`alamat`,`email`,`no_hp`,`maps`,`yt`,`ig`,`tiktok`) VALUES (null, '$alamat','$email','$no_hp','$maps','$yt','$ig','$tiktok')");
header('Location:dashboard_admin.php?p=data_media&notif=sukses');
}


 ?>