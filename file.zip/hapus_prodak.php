<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus=mysqli_query($konek, "DELETE  FROM tb_prodak WHERE id_prodak='$id'");

header("Location:dashboard_admin.php?p=data_prodak&notif=sukses_hapus");

 ?>