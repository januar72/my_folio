<?php
include 'koneksi.php'; 
$direktori ="berkas/";
$file_name =$_FILES['foto']['name'];
move_uploaded_file($_FILES['foto']['tmp_name'],$direktori.$file_name);
$nama =$_POST['nama'];
$profesi =$_POST['profesi'];
$biografi =$_POST['biografi'];

$simpan =mysqli_query($konek, "INSERT INTO `tb_angota` (`id_angota`,`nama`,`profesi`,`biografi`,`foto`) VALUES (null, '$nama','$profesi','$biografi','$file_name') ");
// var_dump($simpan);
// die();
header("Location:dashboard_admin.php?p=data_anggota&notif=sukses");


 ?>