<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus =mysqli_query($konek, "DELETE FROM tb_project WHERE id_project='$id'");
header("Location:dashboard_admin.php?p=data_progres&notif=sukses_hapus");

 ?>