<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus =mysqli_query($konek, "DELETE FROM tb_about WHERE id_about='$id'");
header("Location:dashboard_admin.php?p=data_about&notif=sukses_hapus");

 ?>