
   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#e2edff" fill-opacity="1" d="M0,256L40,229.3C80,203,160,149,240,160C320,171,400,245,480,272C560,299,640,277,720,266.7C800,256,880,256,960,234.7C1040,213,1120,171,1200,176C1280,181,1360,235,1400,261.3L1440,288L1440,320L1400,320C1360,320,1280,320,1200,320C1120,320,1040,320,960,320C880,320,800,320,720,320C640,320,560,320,480,320C400,320,320,320,240,320C160,320,80,320,40,320L0,320Z"></path></svg>
   <!-- akhir kontak -->

   <!-- awal footer -->
   <footer class="text-black text-center pb-5" style="background-color: #e2edff;">
    <?php  include 'koneksi.php';
    $tampil=mysqli_query($konek, "SELECT * FROM tb_media");
    while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) { ?>
    <div class="social">
      <a href="<?php echo $data['ig']; ?>">
        <i class="fa-brands fa-instagram fa-lg"></i>
      </a>
      <a href="<?php echo $data['yt']; ?>">
        <i class="fa-brands fa-youtube fa-lg"></i>
      </a>
      <a href="<?php echo $data['tiktok']; ?>">
        <i class="fa-brands fa-tiktok fa-lg"></i>
      </a>
    </div>
  <?php } ?>
     <p>Created by &copy;  <a href=""> jeen</a> <?php echo date("Y"); ?> <i class="bi bi-arrow-through-heart text-danger"></i></p>
   </footer>
   <!-- akhir footer -->
   <!-- js -->
   <script type="text/javascript" src="frontend/app.js"></script>
   <!-- akhir -->
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- footer watshap -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+62 82339619693", // WhatsApp number
            call_to_action: "call me by watshap..!", // Call to action
            button_color: "#FF6550", // Color of button
            position: "left", // Position may be 'right' or 'left'
            pre_filled_message: "call me by watshap..!", // WhatsApp pre-filled message
        };
        var proto = 'https:', host = "getbutton.io", url = proto + '//static.' + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->
  </body>
</html>