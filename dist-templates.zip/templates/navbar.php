  <!-- awal navbar -->
   <nav class="navbar navbar-expand-lg navbar-dark shadow-sm fixed-top bg-info" >
    <div class="container">
      <a class="navbar-brand" href="index.php">My <span>project</span></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto"> 
          <li class="nav-item">
            <a class="nav-link active" href="about.php">About</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link active" href="project.php">My Folio</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link active dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Services
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item text-center" href="team.php">Our Team</a></li>
              <hr>
              <li><a class="dropdown-item text-center" href="prodak.php">Our Prodak</a></li>
              <hr>
              <li><a class="dropdown-item text-center" href="login.php"><i class="bi bi-box-arrow-in-right"></i> Login</a></li>
            </ul>
          </li>
          <li class="nav-item ">
            <a class="nav-link active" href="kontak.php">Contact Me</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link active" href=""></a>
          </li>
        </ul>
      </div>
    </div>
   </nav>
   <!-- akhir navbar -->