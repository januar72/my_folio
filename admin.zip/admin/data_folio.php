<section class="content-header">
	<h1>
		<small>Data Portfolio</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"> Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Data Portfolio</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-3">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Input Data Portfolio</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form method="post" action="proses_portfolio.php" enctype="multipart/form-data">
						<div class="form-group">
							<label>ketrangan</label>
							<textarea rows="5" cols="5" name="ket" class="form-control" required></textarea>
						</div>
						<div class="form-group">
							<label>Link Projek</label>
							<input type="text" name="proj" class="form-control">
						</div>
						<div class="form-group">
							<label>CV</label>
							<input type="file" name="cv" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Gambar</label>
							<input type="file" name="baner" class="form-control" required>
						</div>
						<div class="box-footer">
							<button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-lg-9">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Data Portfolio</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Ketrangan</th>
								<th>Link Project</th>
								<th>CV</th>
								<th>Gambar</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no=1;
							$tampil=mysqli_query($konek, "SELECT * FROM tb_myfolio");
							while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) { ?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['ket']; ?></td>
									<td><?php echo $data['proj']; ?></td>
									<td><a href="download.php?filename=<?php echo $data['cv']; ?>" class="btn btn-danger">Download</a></td>
									<td>
										<a href="dashboard_admin.php?p=baner&baner=<?php echo $data['baner']; ?>" class="btn btn-danger btn-xs" style="padding: 0;">
											<img src="./berkas/<?php echo $data['baner']; ?>" width="50" height="50">
										</a>
									</td>
									<td>
										<a href="hapus_folio.php?id=<?php echo $data['id_folio']; ?>" class="btn btn-primary btn-xs"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>