<section class="content-header">
	<h1>
		<small>Detail Testimoni</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"> Dashboard</i></a></li>
		<li class="">Admin</li>
		<li class="active">Detail Testimoni</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-12">	
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Detail Testimonial</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama</th>
								<th>Set Status</th>
								<th>Pesan</th>
								<th>Status</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no =1;
							$panggil=mysqli_query($konek, "SELECT * FROM tb_pesan");
							while ($data=mysqli_fetch_array($panggil, MYSQLI_ASSOC)) { ?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['nama']; ?></td>
									<td>
										<?php if ($data['status']==1) {?>
											<a href="proses_aktif.php?id=<?php echo $data['id_pesan']; ?>" class="btn btn-sm btn-danger">Non Aktif</a>
										<?php }else{ ?>
											<a href="proses_aktif.php?id=<?php echo $data['id_pesan']; ?>" class="btn btn-sm btn-success">Aktif</a>
										<?php } ?>
									</td>
									<td><?php echo $data['pesan']; ?></td>
									<td>
										<label class="label
											<?php if ($data['status']==1) {
												echo "label-success";
											}else{
												echo "label-danger";
											} ?>">
											<?php if ($data['status']==1) {
												echo "Aktif";
											}elseif ($data['status'] == 0) {
												echo "Non Aktif";
											} ?>
										</label>
									</td>
									<td>
										<a href="hapus_pesan.php?id=<?php echo $data['id_pesan']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>