  <!-- Content Header (Page header) -->
      <section class="content-header">
        
      </section>
      <section class="content" style="padding-top: 4rem;">
        <div class="row">
          <div class="col-lg-12">
            <div class="box box-default">
              <div class="box-header with-border">
                <h3 class="box-title">FOTO PROJECT</h3>
              </div>
              <div class="box-body" style="width: auto; overflow-x: auto;">
                <?php
                  $foto=$_GET['project'];
                ?>
                <img src="./berkas/<?php echo $foto;?>" width="500">
             </div>
            </div>
            <button class="block btn btn-danger" type="button"><a href="dashboard_admin.php?p=data_progres" style="color: white;">Back</a></button>
          </div>
        </div>
      </section>
      <!-- /.content -->

    