  <!-- Content Header (Page header) -->
      <section class="content-header">
      </section>
      <section class="content">
                <?php
                  include"koneksi.php";
                  $id=$_GET['id'];
                  $query_panggil=mysqli_query($konek, "SELECT * FROM tbl_barang WHERE id_barang='$id'");
                  $data_panggil=mysqli_fetch_array($query_panggil);
                ?>       
            <div class="box box-default">
              <div class="box-header with-border">
                <h3 class="box-title">Form Edit Data Barang</h3>
              </div>
              <div class="box-body">
                
                <form role="form" method="post" action="proses_edit_barang.php?id=<?php echo $id;?>">
                  <div class="box-body">
                    <div class="row">
                      <div class="col-lg-3">
                        <div class="form-group">
                          <label>Nama Barang</label>
                          <input type="text" class="form-control" value="<?php echo $data_panggil['nm_barang'];?>" name="nama" required="required">
                        </div>
                      </div>
                      <div class="col-lg-3">
                        <div class="form-group">
                          <label>Stok</label>
                          <input type="text" class="form-control" value="<?php echo $data_panggil['stok'];?>" name="stok" required="required">
                        </div>
                      </div>
                      <div class="col-lg-3">
                        <div class="form-group">
                          <label>Satuan</label>
                          <select class="form-control" name="satuan" required="required">
                            <?php
                              $query_pq=mysqli_query($konek, "SELECT * FROM tbl_satuan");
                              while($data_pq=mysqli_fetch_array($query_pq)){
                                echo"<option value='".$data_pq['nm_satuan']."'>".$data_pq['nm_satuan']."</option>";
                            }?>
                          </select>
                        </div>
                      </div>
                       <div class="col-lg-3">
                        <div class="form-group">
                          <label>Kategori</label>
                          <select class="form-control" name="kategori" required="required">
                            <option value="Barang Belanja">Barang Belanja</option>
                          </select>
                        </div>
                      </div>
                    
                  </div>
                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
              </div>
              <!-- /.box-body -->
            </div>
          
      </section>
      <!-- /.content -->