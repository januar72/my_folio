<section class="content-header">
	<h1>
		<small>Data About</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard">Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Data About</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-3">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Input Data About</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form method="post" action="proses_about.php">
						<div class="form-group">
							<label>Visi</label>
							<textarea cols="3" rows="5" name="visi" class="form-control"></textarea>
						</div>
						<div class="form-group">
							<label>Misi</label>
							<textarea cols="3" rows="5" name="misi" class="form-control"></textarea>
						</div>
						<div class="box-footer">
							<input type="submit" name="simpan" value="simpan" class="btn btn-primary">
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-lg-9">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Data About</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<?php
			          if(isset($_GET['notif'])){
			            if($_GET['notif']=="sukses"){
			              echo "
			              <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
			              <a href='dashboard_admin.php?p=data_about' class='close' style='text-decoration:none'>&times;</a>
			              <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
			                Data About baru berhasil disimpan...
			              </div>";
			            }if($_GET['notif']=="sukses_edit"){
			              echo "
			              <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
			              <a href='dashboard_admin.php?p=data_about' class='close' style='text-decoration:none'>&times;</a>
			              <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
			                Data About berhasil diedit...
			              </div>";
			            
			             }if($_GET['notif']=="sukses_hapus"){
			              echo "
			              <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
			              <a href='dashboard_admin.php?p=data_about' class='close' style='text-decoration:none'>&times;</a>
			              <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
			                Data About berhasil dihapus...
			              </div>";
			            }
			          }else{
			              echo"";
			          }
			        ?>
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Visi</th>
								<th>Misi</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no=1;
							$panggil =mysqli_query($konek, "SELECT * FROM tb_about ORDER BY id_about DESC");
							while ($data=mysqli_fetch_array($panggil, MYSQLI_ASSOC)) : ?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['visi']; ?></td>
									<td><?php echo $data['misi']; ?></td>
									<td>
										<a href="hapus_about.php?id=<?php echo $data['id_about']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php endwhile; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>

