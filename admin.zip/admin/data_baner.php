<section class="content-header">
	<h1>
		<small>Data Baner</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard">Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Data Baner</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-3">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Input Data Baner</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form method="post" action="proses_baner.php" enctype="multipart/form-data">
						<div class="form-group">
							<label>Gambar</label>
							<input type="file" name="gambar" class="form-control" required>
						</div>
						<div class="box-footer">
							<input type="submit" name="simpan" value="simpan" class="btn btn-primary">
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-lg-9">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Data Baner</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<?php
			          if(isset($_GET['notif'])){
			            if($_GET['notif']=="sukses"){
			              echo "
			              <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
			              <a href='dashboard_admin.php?p=data_baner' class='close' style='text-decoration:none'>&times;</a>
			              <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
			                Data Baner baru berhasil disimpan...
			              </div>";
			            }if($_GET['notif']=="sukses_edit"){
			              echo "
			              <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
			              <a href='dashboard_admin.php?p=data_baner' class='close' style='text-decoration:none'>&times;</a>
			              <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
			                Data Baner berhasil diedit...
			              </div>";
			            
			             }if($_GET['notif']=="sukses_hapus"){
			              echo "
			              <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
			              <a href='dashboard_admin.php?p=data_baner' class='close' style='text-decoration:none'>&times;</a>
			              <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
			                Data Baner berhasil dihapus...
			              </div>";
			            }
			          }else{
			              echo"";
			          }
			        ?>
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Baner
									<i style="font-style: 8px;"></i>
								</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no=1;
							$panggil =mysqli_query($konek, "SELECT * FROM tb_baner ORDER BY id_baner DESC");
							while ($data=mysqli_fetch_array($panggil, MYSQLI_ASSOC)) : ?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td>
										<a href="dashboard_admin.php?p=gambar&gambar=<?php echo $data['gambar']; ?>" class="btn btn-danger" style="padding: 0;">
						                     <img src="./berkas/<?php echo $data['gambar'];?>" style="width: 50px; height: 50px;">
						                </a>
									</td>
									<td>
										<a href="hapus_baner.php?id=<?php echo $data['id_baner']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php endwhile; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>

