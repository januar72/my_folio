<section class="content-header">
	<h1>
		<small>Data Anggota</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""></a><i class="fa fa-dashboard"> Dashboard</i></li>
		<li><a href="">Admin</a></li>
		<li class="active">Data Anggota</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-3">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Input Data Anggota</h3>
				</div>
				<div class="box-body">
      	<?php
          if(isset($_GET['notif'])){
            if($_GET['notif']=="gagal"){
              echo "
              <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
              <a href='dashboard_admin.php?p=Anggota' class='close' style='text-decoration:none'>&times;</a>
              <h4 style='font-size:12px;'><i class='icon fa fa-ban'></i> Gagal!</h4>
                Nama Anggota yang anda masukkan sudah terdaftar....
              </div>";
            }
          }else{
              echo"";
          }
        ?>
        <form method="post" action="proses_anggota.php" enctype="multipart/form-data">
        	<div class="box-body">
        		<div class="form-group">
        			<label>Nama</label>
        			<input type="text" name="nama" class="form-control" required>
        		</div>
        		<div class="form-group">
        			<label>Profesi</label>
        			<textarea name="profesi" class="form-control" required cols="3" rows="3"></textarea>
        		</div>
        		<div class="form-group">
        			<label>Biografi</label>
        			<textarea name="biografi" class="form-control" required cols="3" rows="4"></textarea>
        		</div>
        		<div class="form-group">
        			<label>Foto</label>
        			<input type="file" name="foto" class="form-control" required>
        		</div>
        		<div class="box-footer">
        			<input type="submit" name="simpan" class="btn btn-primary">
        		</div>
        	</div>
        </form>
				</div>
			</div>
		</div>
		<div class="col-lg-9">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Data Anggota</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<?php
          if(isset($_GET['notif'])){
            if($_GET['notif']=="sukses"){
              echo "
              <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
              <a href='dashboard_admin.php?p=anggota' class='close' style='text-decoration:none'>&times;</a>
              <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
                Data anggota baru berhasil disimpan...
              </div>";
            }if($_GET['notif']=="sukses_edit"){
              echo "
              <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
              <a href='dashboard_admin.php?p=anggota' class='close' style='text-decoration:none'>&times;</a>
              <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
                Data anggota berhasil diedit...
              </div>";
            
             }if($_GET['notif']=="sukses_hapus"){
              echo "
              <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
              <a href='dashboard_admin.php?p=anggota' class='close' style='text-decoration:none'>&times;</a>
              <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
                Data anggota berhasil dihapus...
              </div>";
            }
          }else{
              echo"";
          }
        ?>
        <table id="example1" class="table table-bordered table-striped">
        	<thead>
        		<tr>
        			<th>No</th>
        			<th>Nama</th>
        			<th>Profesi</th>
        			<th>Biografi</th>
        			<th>Foto<br>
        				<i style="font-style: 8px;">* klik gambar</i></th>
        			<th>Aksi</th>
        		</tr>
        	</thead>
        	<tbody>
        		<?php include './koneksi.php';
        		$no=1;
        		$tampil =mysqli_query($konek, "SELECT * FROM tb_angota");
        		while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) { ?>
        			<tr>
        				<td><?php echo $no++; ?></td>
        				<td><?php echo $data['nama']; ?></td>
        				<td><?php echo $data['profesi']; ?></td>
        				<td><?php echo $data['biografi']; ?></td>
        				<td>
      					<a href="dashboard_admin.php?p=foto&foto=<?php echo $data['foto']; ?>" class="btn btn-danger" style="padding: 0;">
                     <img src="./berkas/<?php echo $data['foto'];?>" style="width: 50px; height: 50px;">
                </a>
        				</td>
        				<td>
        					<a href="hapus_anggota.php?id=<?php echo $data['id_angota']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
        				</td>
        			</tr>
        		<?php } ?>
        	</tbody>
        </table>
				</div>
			</div>
		</div>
	</div>
</section>