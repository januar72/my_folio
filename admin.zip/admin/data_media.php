<section class="content-header">
	<h1>
		<small>Input Social Media</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
		<li><a href="#">Admin</a></li>
		<li class="active">Social Media</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-3">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Input Data Media</h3>
				</div>
				<div class="box-body">
					<?php
            if(isset($_GET['notif'])){
              if($_GET['notif']=="gagal"){
                echo "
                <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
                <a href='dashboard_admin.php?p=barang' class='close' style='text-decoration:none'>&times;</a>
                <h4 style='font-size:12px;'><i class='icon fa fa-ban'></i> Gagal!</h4>
                  Nama barang yang anda masukkan sudah terdaftar....
                </div>";
              }
            }else{
                echo"";
            }
          ?>
        <form method="post" action="proses_media.php">
        	<div class="box-body">
        		<div class="form-group">
        			<label>Alamat</label>
        			<input type="text" name="alamat" class="form-control" required>
        		</div>
        		<div class="from-group">
        			<label>Email</label>
        			<input type="email" name="email" class="form-control" required>
        		</div>
        		<div class="form-group">
        			<label>No Hp</label>
        			<input type="text" name="no_hp" class="form-control" required>
        		</div>
        		<div class="form-group">
        			<label>Maps</label>
        			<textarea name="maps" class="form-control" required cols="5" rows="10"></textarea>
        		</div>
        		<div class="form-group">
        			<label>Youtube</label>
        			<input type="text" placeholder="masukan link youtbe" name="yt" class="form-control" required>
        		</div>
        		<div class="form-group">
        			<label>Instagram</label>
        			<input type="text" placeholder="masukan link instagram" name="ig" class="form-control" required>
        		</div>
            <div class="form-group">
              <label>Tik Tok</label>
              <input type="text" name="tiktok" class="form-control" required placeholder="masukan tik tok">
            </div>
        		<div class="box-footer">
        			<button type="submit" name="simpan" class="btn btn-primary"> Simpan</button>
        		</div>
        	</div>
        </form>
				</div>
			</div>
		</div>
		<div class="col-lg-9">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Data Media</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<?php
            if(isset($_GET['notif'])){
              if($_GET['notif']=="sukses"){
                echo "
                <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
                <a href='dashboard_admin.php?p=data_media' class='close' style='text-decoration:none'>&times;</a>
                <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
                  Data media baru berhasil disimpan...
                </div>";
              }if($_GET['notif']=="sukses_edit"){
                echo "
                <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
                <a href='dashboard_admin.php?p=data_media' class='close' style='text-decoration:none'>&times;</a>
                <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
                  Data media berhasil diedit...
                </div>";
              
               }if($_GET['notif']=="sukses_hapus"){
                echo "
                <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
                <a href='dashboard_admin.php?p=data_media' class='close' style='text-decoration:none'>&times;</a>
                <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
                  Data media berhasil dihapus...
                </div>";
              }
            }else{
                echo"";
            }
          ?>
        <table id="example1" class="table table-bordered table-striped">
        	<thead>
        		<tr>
        			<th>No</th>
        			<th>Alamat</th>
        			<th>Email</th>
        			<th>No Hp</th>
        			<th>Maps</th>
              <th>Youtube</th>
              <th>Instagram</th>
              <th>Tik Tok</th>
              <th>Action</th>
        		</tr>
        	</thead>
          <tbody>
            <?php $no =1;
            $tampil =mysqli_query($konek,"SELECT * FROM tb_media ORDER BY id_media DESC");
            while ($data =mysqli_fetch_array($tampil, MYSQLI_ASSOC)) { ?>
              <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $data['alamat']; ?></td>
                <td><?php echo $data['email']; ?></td>
                <td><?php echo $data['no_hp']; ?></td>
                <td>
                  <iframe src="<?php echo $data['maps']; ?>" style="border: 0; width: 200px;" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </td>
                <td><?php echo $data['yt']; ?></td>
                <td><?php echo $data['ig']; ?></td>
                <td><?php echo $data['tiktok']; ?></td>
                <td>
                  <a href="hapus_media.php?id=<?php echo $data['id_media']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
				</div>
			</div>
		</div>
	</div>
</section>